document.addEventListener("DOMContentLoaded", function () {
    const cityInput = document.getElementById("city-input");
    const fetchButton = document.getElementById("fetch-button");
    const dataContainer = document.getElementById("data-container");




});
