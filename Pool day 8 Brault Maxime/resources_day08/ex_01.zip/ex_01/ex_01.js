var splide = new Splide( '.splide', {
  type   : 'loop',
  perPage: 1,
  autoplay: true,
  interval: 5000,
  start:1,
  padding: '10rem',
  gap: 50,
  focus: 'center',
} );
splide.mount();
